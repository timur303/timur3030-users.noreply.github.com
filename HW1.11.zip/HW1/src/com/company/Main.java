package com.company;

public class Main {

    public static void main(String[] args) {
	// HM1
        String myNameIs= "222";
        //
        int NUM = 3;
        String word ="Три";

        System.out.println(NUM+word+myNameIs);
    }
}
